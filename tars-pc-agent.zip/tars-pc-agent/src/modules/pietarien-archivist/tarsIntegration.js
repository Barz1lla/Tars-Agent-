const TarsClient = require("../../shared/tarsClient");
const logger = require("../../shared/logger");

class PietarienTarsIntegration {
  constructor(settings) {
    this.tarsClient = new TarsClient(settings.models);
    this.prompts = settings.prompts;
  }

  async categorizeContent(content) {
    logger.info("Sending content to TARS for categorization...");
    try {
      const result = await this.tarsClient.callModel(
        this.tarsClient.defaultModel,
        this.prompts.categorization.pietarien,
        content
      );
      logger.info(`TARS categorization response: ${result.text}`);
      return result.text.trim();
    } catch (error) {
      logger.error(`Error categorizing content with TARS: ${error.message}`);
      throw error;
    }
  }
}

module.exports = PietarienTarsIntegration;

