const fs = require("fs").promises;
const path = require("path");
const logger = require("../../shared/logger");

async function scan(directory, extensions, callback) {
  try {
    const files = await fs.readdir(directory, { withFileTypes: true });

    for (const file of files) {
      const fullPath = path.join(directory, file.name);
      if (file.isDirectory()) {
        await scan(fullPath, extensions, callback); // Recurse into subdirectories
      } else if (file.isFile() && extensions.includes(path.extname(file.name))) {
        await callback(fullPath);
      }
    }
  } catch (error) {
    logger.error(`Error scanning directory ${directory}: ${error.message}`);
    throw error;
  }
}

module.exports = { scan };

