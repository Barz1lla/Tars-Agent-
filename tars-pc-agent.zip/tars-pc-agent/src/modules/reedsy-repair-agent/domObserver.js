const logger = require("../../shared/logger");

let observer;

function startObserving(callback) {
  // This is a simplified observer. In a real browser environment,
  // you would use MutationObserver to detect DOM changes.
  // For this simulation, we'll just log that observation started.
  logger.info("DOM observation started. (Simulation)");
  // In a real scenario, you'd attach a MutationObserver to the DOM
  // observer = new MutationObserver(callback);
  // observer.observe(document.body, { childList: true, subtree: true, attributes: true });

  // For demonstration, we'll call the callback periodically to simulate changes
  setInterval(() => {
    // Simulate a mutation record
    callback([{ type: "simulated_mutation" }]);
  }, 5000); // Simulate changes every 5 seconds
}

function stopObserving() {
  if (observer) {
    observer.disconnect();
    logger.info("DOM observation stopped.");
  }
}

module.exports = {
  startObserving,
  stopObserving,
};

