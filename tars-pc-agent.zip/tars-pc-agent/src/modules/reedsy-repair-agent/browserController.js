const puppeteer = require("puppeteer");
const logger = require("../../shared/logger");

let browser;
let page;

async function navigateTo(url) {
  if (!browser) {
    browser = await puppeteer.launch({ headless: false }); // Set to true for headless mode
  }
  page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle2" });
  logger.info(`Navigated to ${url}`);
}

async function clickElement(selector) {
  await page.click(selector);
  logger.info(`Clicked element: ${selector}`);
}

async function typeText(selector, text) {
  await page.type(selector, text);
  logger.info(`Typed text into ${selector}`);
}

async function getHtmlContent(selector = "body") {
  const content = await page.$eval(selector, (element) => element.innerHTML);
  return content;
}

async function pasteContent(content) {
  // This is a placeholder. Real implementation would involve more complex browser interaction
  // like finding the active editor, clearing its content, and then pasting.
  logger.warn(`Attempted to paste content (not fully implemented): ${content.substring(0, 100)}...`);
}

async function closeBrowser() {
  if (browser) {
    await browser.close();
    browser = null;
    page = null;
    logger.info("Browser closed.");
  }
}

module.exports = {
  navigateTo,
  clickElement,
  typeText,
  getHtmlContent,
  pasteContent,
  closeBrowser,
};

