const logger = require("../../shared/logger");
const TarsClient = require("../../shared/tarsClient");
const settings = require("../../../config/settings.json");
const prompts = require("../../../config/prompts.json");
const rules = require("../../../config/rules.json");
const browserController = require("./browserController");
const domObserver = require("./domObserver");
const formatter = require("./formatter");

class ReedsyRepairAgent {
  constructor() {
    this.tarsClient = new TarsClient(settings.models);
    this.editorUrl = settings.reedsy.editorUrl;
    this.autoFixEnabled = settings.reedsy.autoFixEnabled;
    this.checkInterval = settings.reedsy.checkInterval;
  }

  async repair() {
    logger.info("Starting Reedsy Repair Agent...");
    try {
      // 1. Navigate to Reedsy editor
      await browserController.navigateTo(this.editorUrl);
      logger.info(`Navigated to Reedsy editor: ${this.editorUrl}`);

      // 2. Start observing DOM for changes
      domObserver.startObserving(async (mutations) => {
        logger.info("DOM mutations detected. Checking for formatting issues...");
        const htmlContent = await this.tarsClient.getDOMContent("body"); // Get full body HTML

        // 3. Analyze content for issues using AI
        const analysisResult = await this.tarsClient.callModel(
          this.tarsClient.defaultModel,
          prompts.formatting.detectIssues,
          htmlContent
        );
        const issues = JSON.parse(analysisResult.text);
        logger.info(`Detected issues: ${JSON.stringify(issues)}`);

        if (this.autoFixEnabled && issues.length > 0) {
          logger.info("Auto-fix is enabled. Applying fixes...");
          for (const issue of issues) {
            const fixedContent = formatter.applyRule(htmlContent, issue, rules);
            // 4. Apply fixes via browser automation (e.g., paste content back)
            // This part is highly dependent on Reedsy's editor implementation.
            // For demonstration, we'll just log the fixed content.
            logger.info(`Applied fix for issue: ${JSON.stringify(issue)}`);
            // In a real scenario, you'd use browserController to interact with the editor
            // e.g., await browserController.pasteContent(fixedContent);
          }
        }
      });

      logger.info(`Reedsy Repair Agent is running. Observing for changes every ${this.checkInterval / 1000} seconds.`);
      logger.info("Press Ctrl+C to stop the agent.");

      // Keep the process alive
      setInterval(() => {}, this.checkInterval);

    } catch (error) {
      logger.error(`Reedsy Repair Agent failed: ${error.message}`);
    }
  }
}

module.exports = ReedsyRepairAgent;

